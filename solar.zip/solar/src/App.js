import React, { useState, useEffect } from 'react';
import './App.css';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { from, zip } from 'rxjs';
import { switchMap, map, catchError } from 'rxjs/operators';

function App() {
  const [planets, setPlanets] = useState([]);
  const [nextPage, setNextPage] = useState(null);

  useEffect(() => {
    fetchPlanets('https://swapi.dev/api/planets/?format=json');
  }, []);

  const fetchPlanets = (url) => {
    from(fetch(url))
      .pipe(
        switchMap(response => response.json()),
        map(data => {
          setPlanets(data.results);
          setNextPage(data.next);
        }),
        catchError(error => console.error('Error fetching planets:', error))
      )
      .subscribe();
  };

  const fetchNextPage = () => {
    if (nextPage) {
      fetchPlanets(nextPage);
    }
  };

  return (
    <Router>
      <div className="App">
        <header>
          <h1>Star Wars Planets Directory</h1>
        </header>
        <main>
          <Routes>
            <Route path="/" element={<HomePage planets={planets} fetchNextPage={fetchNextPage} />} />
            <Route path="/planet/:id" element={<PlanetDetailsPage planets={planets} />} />
          </Routes>
        </main>
        <footer>
          <p>© 2024 Star Wars</p>
        </footer>
      </div>
    </Router>
  );
}

const HomePage = ({ planets, fetchNextPage }) => (
  <div>
    <div className="planets">
      {planets.map((planet, index) => (
        <div className="planet-card" key={index}>
          <Link to={`/planet/${index}`}>
            <h2>{planet.name}</h2>
          </Link>
        </div>
      ))}
    </div>
    <button onClick={fetchNextPage} className="load-more-btn">
      Load More
    </button>
  </div>
);

const PlanetDetailsPage = ({ planets }) => {
  const location = useLocation();
  const planetIndex = parseInt(location.pathname.split('/')[2]);
  const planet = planets[planetIndex];

  return (
    <div>
      <div className="planet-details-card">
        <h2>{planet.name}</h2>
        <p><strong>Climate:</strong> {planet.climate}</p>
        <p><strong>Population:</strong> {planet.population !== 'unknown' ? planet.population : 'Unknown'}</p>
        <p><strong>Terrain:</strong> {planet.terrain}</p>
        {planet.population !== 'unknown' && <ResidentsButton residentsUrls={planet.residents} />}
      </div>
      <Link to="/" className="home-btn">
        Home
      </Link>
    </div>
  );
};

const ResidentsButton = ({ residentsUrls }) => {
  const [showResidents, setShowResidents] = useState(false);
  const [residents, setResidents] = useState([]);

  const toggleResidents = () => {
    const requests = residentsUrls.map(url => from(fetch(url)).pipe(switchMap(response => response.json())));
    zip(...requests)
      .pipe(
        map(data => {
          setResidents(data);
          setShowResidents(!showResidents);
        }),
        catchError(error => console.error('Error fetching residents:', error))
      )
      .subscribe();
  };

  return (
    <div>
      <button onClick={toggleResidents} className="residents-button">
        {showResidents ? 'Hide Residents' : 'Show Residents'}
      </button>
      {showResidents && <Residents residents={residents} />}
    </div>
  );
};

const Residents = ({ residents }) => (
  <div className="residents-card">
    <h3>Residents:</h3>
    <ul>
      {residents.map((resident, index) => (
        <li key={index}>
          <p><strong>Name:</strong> {resident.name}</p>
          <p><strong>Height:</strong> {resident.height}</p>
          <p><strong>Mass:</strong> {resident.mass}</p>
          <p><strong>Gender:</strong> {resident.gender}</p>
        </li>
      ))}
    </ul>
  </div>
);

export default App;
